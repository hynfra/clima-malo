function saludarUsuario(){
    alert("Hola usuario, bienvenido/a")
}
$("#saludar").on("click",saludarUsuario)