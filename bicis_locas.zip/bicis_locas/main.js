function validateForm () {
  // your code here
}