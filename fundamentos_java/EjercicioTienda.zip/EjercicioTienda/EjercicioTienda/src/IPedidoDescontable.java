public interface IPedidoDescontable {

    final double porcentajeDescuento = 0.13;

    double calcularDescuento(String horario);



}
