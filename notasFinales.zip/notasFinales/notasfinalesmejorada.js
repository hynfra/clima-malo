

for( let i = 1; i <= 10; i++){

}
function agregarNotas(nota, i){
    let mensaje = "Ingrese nota"
    switch(i){
        case 1,2,3:
            mensaje+= "[html]"
            break;
            case 4,5,6:
                mensaje+="[CSS]"
            break;
            case 7,8,9:
                mensaje+="[JAVASCRIPT]"

    }
 nota = parseInt(nota)
 if(i <= 2){

 }
}